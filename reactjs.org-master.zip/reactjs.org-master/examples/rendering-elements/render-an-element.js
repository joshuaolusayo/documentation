const element = <h1>Hello, world</h1>;
ReactDOM.render(element, document.getElementById('root'));
