---
title: A Component Using External Plugins
order: 3
domid: markdown-example
---

React allows you to interface with other libraries and frameworks. This example uses **remarkable**, an external Markdown library, to convert the `<textarea>`'s value in real time.
