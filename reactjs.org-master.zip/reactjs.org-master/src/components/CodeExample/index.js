/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @flow
 */

import CodeExample from './CodeExample';

export default CodeExample;
