/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import TitleAndMetaTags from './TitleAndMetaTags';

export default TitleAndMetaTags;
