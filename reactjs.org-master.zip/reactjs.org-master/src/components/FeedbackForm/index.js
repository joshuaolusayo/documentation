/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import FeedbackForm from './FeedbackForm';

export default FeedbackForm;
